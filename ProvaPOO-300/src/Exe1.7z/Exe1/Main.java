package Exe1;

public class Main {

	public static void main(String[] args) {
		
		Pessoa pessoas = new Pessoa (80.0f,1.84f);
		pessoas.andar();
		pessoas.correr();
		
		Aluno alunos = new Aluno (90.0f,1.85f);
		alunos.andar();
		alunos.correr();
	}

}
